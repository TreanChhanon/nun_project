<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['ProductID'])) {
    $productID = $_POST['ProductID'];

    $func = new functions();
    $delete = $func->delete_data('tblproducts', 'ProductID', $productID);

    if ($delete == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Product deleted successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to delete the product.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
