<?php
include('functions.php');
$result = array("success"=>0,"errors"=>0);

if(isset($_POST["FullNameReg"]) && isset($_POST["UserNameReg"]) && isset($_POST["UserImage"])){
    $fullname = $_POST["FullNameReg"];
    $username = $_POST["UserNameReg"];
    $userpass = md5($_POST["PasswordReg"]);
    $image = $_POST["UserImage"];
    $image_name = $username . ".jpg"; // Assuming username is unique and using it as the image name

    // Path where the image will be stored
    $path = "images/contacts/" . $image_name;

    // Fields and values for insertion
    $fields = array("UserName", "UserPassword", "FullName", "UserImage");
    $values = array($username, $userpass, $fullname, $image_name);

    // Create an object of the functions class
    $func = new functions();

    // Insert data into the database
    $insert = $func->insert_data("tbluser", $fields, $values);

    if($insert == true){
        // If insertion successful, store the image
        file_put_contents($path, base64_decode($image));

        // Set success response
        $result["success"] = 1;
        $result["msg_success"] = "Registered user successfully!";
        echo json_encode($result);
    } else {
        // Set error response
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to register the user.";
        echo json_encode($result);
    }
} else {
    // If required parameters are not provided
    $result["errors"] = 1;
    $result["msg_errors"] = "Access denied...";
    echo json_encode($result);
}
?>
