<?php
include('functions.php');
$result = array("success" => 0, "errors" => 0);
if (isset($_POST['NewContactName']) && isset($_POST['NewPhone'])) {
    $name = $_POST['NewContactName'];
    $phone = $_POST['NewPhone'];
    $email = $_POST['NewEmail'];
    $image = $_POST['NewImage'];
    $image_name = $name . ".jpg";
    $path = "images/contacts/" . $image_name;

    if ($image == "NoImage") {
        $fields = array("contactName", "contactNumber", "contactEmail");
        $values = array($name, $phone, $email);
    } else {
        $fields = array("contactName", "contactNumber", "contactEmail", "contactImage");
        $values = array($name, $phone, $email, $image_name);
    }
    // create an objec of class functions
    $func = new functions();
    $insert = $func->insert_data('tblcontact', $fields, $values);
    if ($insert == true) {
        if ($image != "NoImage") {
            file_put_contents($path, base64_decode($image));
        }
        $result["success"] = 1;
        $result["msg_success"] = "Contact is created";
        print json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to create the contact.";
        print json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Access denied...";
    print json_encode($result);
}
