<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['ContactID'])) {
    $contactID = $_POST['ContactID'];

    $func = new functions();
    $delete = $func->delete_data('tblcontact', 'ContactID', $contactID);

    if ($delete == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Contact deleted successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to delete the contact.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
