<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

// Check if the request contains necessary data
if(isset($_POST['UserID']) && isset($_POST['UserName']) && isset($_POST['UserType']) && isset($_POST['UserEmail'])) {
    $userID = $_POST['UserID'];
    $userName = $_POST['UserName'];
    $userType = $_POST['UserType'];
    $userEmail = $_POST['UserEmail'];

    // Handle image upload
    if(isset($_FILES['UserImage']) && $_FILES['UserImage']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'images/contacts/';
        $imageTempName = $_FILES['UserImage']['tmp_name'];
        $imageExt = strtolower(pathinfo($_FILES['UserImage']['name'], PATHINFO_EXTENSION));
        $image_name = $userID . "_image." . $imageExt; // Unique image name, you can change it as needed
        $path = $uploadDir . $image_name;

        // Move uploaded file to destination directory
        if(move_uploaded_file($imageTempName, $path)) {
            // Image uploaded successfully, update user data
            $func = new functions();
            $fields = array("UserName", "UserType", "UserEmail", "UserImage");
            $values = array($userName, $userType, $userEmail, $image_name);
            $success = $func->update_data('tbluser', $fields, $values, 'UserID', $userID);

            if($success) {
                // User information updated successfully
                $result["success"] = 1;
            } else {
                // Failed to update user information
                $result["errors"] = 1;
                $result["msg_errors"] = "Failed to update user information.";
            }
        } else {
            // Failed to move uploaded file
            $result["errors"] = 1;
            $result["msg_errors"] = "Failed to upload user image.";
        }
    } else {
        // No image uploaded or error occurred
        // Proceed to update user data without the image
        $func = new functions();
        $fields = array("UserName", "UserType", "UserEmail");
        $values = array($userName, $userType, $userEmail);
        $success = $func->update_data('tbluser', $fields, $values, 'UserID', $userID);

        if($success) {
            // User information updated successfully
            $result["success"] = 1;
        } else {
            // Failed to update user information
            $result["errors"] = 1;
            $result["msg_errors"] = "Failed to update user information.";
        }
    }
} else {
    // Insufficient data provided
    $result["errors"] = 1;
    $result["msg_errors"] = "Insufficient data provided.";
}

// Output the result as JSON
echo json_encode($result);
?>
