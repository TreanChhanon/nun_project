<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['CategoryID']) && isset($_POST['CategoryName']) && isset($_POST['Description'])) {
    $categoryID = $_POST['CategoryID'];
    $categoryName = $_POST['CategoryName'];
    $description = $_POST['Description'];

    $fields = array("CategoryName", "Description", "UpdatedDate");
    $values = array($categoryName, $description, date("Y-m-d H:i:s"));

    $func = new functions();
    $update = $func->update_data('tblcategories', $fields, $values, 'CategoryID', $categoryID);

    if ($update == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Category updated successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to update the category.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
