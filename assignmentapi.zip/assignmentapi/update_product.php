<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

// Check if all required parameters are set
if (
    isset($_POST['ProductID']) && isset($_POST['ProductName']) 
    && isset($_POST['Description']) && isset($_POST['CategoryID'])
    && isset($_POST['Barcode']) && isset($_POST['ExpiredDate'])
    && isset($_POST['Qty']) && isset($_POST['UnitPriceIn'])
    && isset($_POST['UnitPriceOut'])
) {
    // Retrieve parameters from POST data
    $productId = $_POST['ProductID'];
    $name = $_POST['ProductName'];
    $description = $_POST['Description'];
    $categoryID = $_POST['CategoryID'];
    $barcode = $_POST['Barcode'];
    $expiredDate = $_POST['ExpiredDate'];
    $qty = $_POST['Qty'];
    $unitPriceIn = $_POST['UnitPriceIn'];
    $unitPriceOut = $_POST['UnitPriceOut'];
    $image = $_POST['ProductImage'];
    $image_name = $name . ".jpg";
    $path = "images/contacts/" . $image_name;

    // Define fields and values arrays based on whether an image is provided
    if ($image == "NoImage") {
        $fields = array(
            "ProductName", "Description", "CategoryID", 
            "Barcode", "ExpiredDate", "Qty", 
            "UnitPriceIn", "UnitPriceOut"
        );
        $values = array(
            $name, $description, $categoryID, 
            $barcode, $expiredDate, $qty, 
            $unitPriceIn, $unitPriceOut
        );
    } else {
        $fields = array(
            "ProductName", "Description", "CategoryID", 
            "Barcode", "ExpiredDate", "Qty", 
            "UnitPriceIn", "UnitPriceOut", "ProductImage"
        );
        $values = array(
            $name, $description, $categoryID, 
            $barcode, $expiredDate, $qty, 
            $unitPriceIn, $unitPriceOut, $image_name
        );
    }

    // Update the product using the update_data function
    $func = new functions();
    $update = $func->update_data('tblproducts', $fields, $values, 'ProductID', $productId);

    // Check if the update was successful and handle accordingly
    if ($update == true) {
        if ($image != "NoImage") {
            file_put_contents($path, base64_decode($image));
        }
        $result["success"] = 1;
        $result["msg_success"] = "Product updated successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to update the product.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
