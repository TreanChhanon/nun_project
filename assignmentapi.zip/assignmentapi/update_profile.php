<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

// Check if the request contains necessary data
if(isset($_POST['UserID'], $_POST['UserName'], $_POST['UserType'], $_POST['UserEmail'], $_POST['FullName'])) {
    $userID = $_POST['UserID'];
    $userName = $_POST['UserName'];
    $userType = $_POST['UserType'];
    $userEmail = $_POST['UserEmail'];
    $fullName = $_POST['FullName'];

    // Handle image upload
    if(isset($_FILES['UserImage']) && $_FILES['UserImage']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'images/contacts/';
        $imageTempName = $_FILES['UserImage']['tmp_name'];
        $imageExt = strtolower(pathinfo($_FILES['UserImage']['name'], PATHINFO_EXTENSION));
        $allowedExts = array("jpg", "jpeg", "png", "gif"); // Allowed image file extensions
        $image_name = $userID . "_image." . $imageExt;

        // Validate file type
        if(!in_array($imageExt, $allowedExts)) {
            $result["errors"] = 1;
            $result["msg_errors"] = "Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.";
        } else {
            $path = $uploadDir . $image_name;
            // Move uploaded file to destination directory
            if(move_uploaded_file($imageTempName, $path)) {
                // Image uploaded successfully, update user data
                $func = new functions();
                $fields = array("UserName", "UserType", "UserEmail", "UserImage", "FullName");
                $values = array($userName, $userType, $userEmail, $image_name, $fullName);
                $success = $func->update_data('tbluser', $fields, $values, 'UserID', $userID);

                if($success) {
                    // User information updated successfully
                    $result["success"] = 1;
                } else {
                    // Failed to update user information
                    $result["errors"] = 1;
                    $result["msg_errors"] = "Failed to update user information.";
                }
            } else {
                // Failed to move uploaded file
                $result["errors"] = 1;
                $result["msg_errors"] = "Failed to upload user image.";
            }
        }
    } else {
        // No image uploaded or error occurred
        // Proceed to update user data without the image
        $func = new functions();
        $fields = array("UserName", "UserType", "UserEmail", "FullName");
        $values = array($userName, $userType, $userEmail, $fullName);
        $success = $func->update_data('tbluser', $fields, $values, 'UserID', $userID);

        if($success) {
            // User information updated successfully
            $result["success"] = 1;
        } else {
            // Failed to update user information
            $result["errors"] = 1;
            $result["msg_errors"] = "Failed to update user information.";
        }
    }
} else {
    // Insufficient data provided
    $result["errors"] = 1;
    $result["msg_errors"] = "Insufficient data provided.";
}

// Output the result as JSON
echo json_encode($result);
?>
