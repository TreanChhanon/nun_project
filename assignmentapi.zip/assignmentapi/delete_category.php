<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['CategoryID'])) {
    $categoryID = $_POST['CategoryID'];

    $func = new functions();
    $delete = $func->delete_data('tblcategories', 'CategoryID', $categoryID);

    if ($delete == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Category deleted successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to delete the category.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
