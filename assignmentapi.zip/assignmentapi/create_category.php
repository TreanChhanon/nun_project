<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['CategoryName']) && isset($_POST['Description'])) {
    $categoryName = $_POST['CategoryName'];
    $description = $_POST['Description'];

    $fields = array("CategoryName", "Description", "CreatedDate");
    $values = array($categoryName, $description, date("Y-m-d H:i:s"));

    $func = new functions();
    $insert = $func->insert_data('tblcategories', $fields, $values);

    if ($insert == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Category created successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to create the category.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}

