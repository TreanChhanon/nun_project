<?php
    include('functions.php');
    $result = array("success"=>0,"errors"=>0);
    if(isset($_POST["UserNameEdit"]) && isset($_POST["UserID"])){
        $fullname = $_POST["FullNameEdit"];
        $username = $_POST["UserNameEdit"];
        $userid = $_POST["UserID"];
        $email = $_POST["EmailEdit"];
        $image = $_POST["ImageEdit"];
        $image_name = $username.".jpg";
        $path = "images/".$image_name;

        $fields = array("UserName","FullName","UserEmail","UserImage");
        $values = array($username,$fullname,$email,$image_name);

        $func = new functions();
        $row = $func->show_data_by_id('tbluser','UserID',$userid);
        $update = $func->update_data('tbluser',$fields,$values,'UserID',$userid);
        if($update == true){
            if($row != false){
                if($row['UserImage'] != 'default.png' && $row['UserImage'] != $image_name){
                    unlink("images/".$row['UserImage']);
                }
            }
            file_put_contents($path,base64_decode($image));
            $result["success"] = 1;
            $result["msg_success"] = "Your profile has been updated.";
            $result["UserNameLogin"] = $username;
            $result["UserFullName"] = $fullname;
            $result["UserEmail"] = $email;
            $result["UserImage"] = $image;
            print json_encode($result);
        }else{
            $result["errors"] = 2;
            $result["msg_errors"] = "Failed to update the user profile.";
            print json_encode($result);
        }
    }else{
        $result["errors"] = 1;
        $result["msg_errors"] = "Access denied...";
        print json_encode($result);
    }
?>