<?php
include('functions.php');

// Check if the request contains a user ID
if(isset($_POST['UserID'])) {
    $userID = $_POST['UserID'];

    // Execute SQL query to fetch user data
    $func = new functions();
    $user = $func->get_user_by_id('tbluser', $userID);

    if($user != false) {
        // User found, populate the result array with user data
        $result["success"] = 1;
        $result["user"] = array(
            "UserID" => $user['UserID'],
            "UserName" => $user['UserName'],
            "UserPassword" => $user['UserPassword'],
            "FullName" => $user['FullName'],
            "UserType" => $user['UserType'],
            "UserEmail" => $user['UserEmail'],
            "UserImage" => base64_encode(file_get_contents($user['UserImage']))
        );
    } else {
        // User not found
        $result["errors"] = 2;
        $result["msg_errors"] = "User not found.";
    }
} else {
    // No user ID provided
    $result["errors"] = 1;
    $result["msg_errors"] = "No user ID provided.";
}

// Output the result as JSON
echo json_encode($result);
?>
