<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

if (isset($_POST['ContactID']) && isset($_POST['NewContactName']) && isset($_POST['NewPhone'])) {
    $contactID = $_POST['ContactID'];
    $name = $_POST['NewContactName'];
    $phone = $_POST['NewPhone'];
    $email = $_POST['NewEmail'];
    $image = $_POST['NewImage'];
    $image_name = $name . ".jpg";
    $path = "images/contacts/" . $image_name;

    if ($image == "NoImage") {
        $fields = array("contactName", "contactNumber", "contactEmail");
        $values = array($name, $phone, $email);
    } else {
        $fields = array("contactName", "contactNumber", "contactEmail", "contactImage");
        $values = array($name, $phone, $email, $image_name);
    }

    $func = new functions();
    $update = $func->update_data('tblcontact', $fields, $values, 'contactID', $contactID);

    if ($update == true) {
        if ($image != "NoImage") {
            file_put_contents($path, base64_decode($image));
        }
        $result["success"] = 1;
        $result["msg_success"] = "Contact updated successfully";
        echo json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to update the contact.";
        echo json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Missing required parameters.";
    echo json_encode($result);
}
?>
