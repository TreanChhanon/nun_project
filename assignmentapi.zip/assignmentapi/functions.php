<?php
    class functions {
        // data members or member variables
        private $db;
        private $sql;
        private $result;
        private $fnum;

        // constructor
        function __construct()
        {
            require_once ('DbConnection.php');
            // create an object of class DbConnection
            $this->db = new DbConnection();
            // call the method connect() of class DbConnection
            $this->db->connect();
        }
        // destructor
        function __destruct()
        {
            // call the method close() of class DbConnection
            $this->db->close();   
        }
        // member methods
        public function insert_data($tablename,$fields,$values){
            // count fields in array : INSERT INTO tablename(col1,col2,...) VALUES(val1,val2,...);
            $this->fnum = count($fields);
            // generate insert statement
            $this->sql = "INSERT INTO $tablename(";
            for($i=0; $i<$this->fnum; $i++){
                $this->sql .= $fields[$i];
                if($i<$this->fnum-1){
                    $this->sql .= ",";
                }else{
                    $this->sql .= ") VALUES(";
                }
            }
            for($i=0; $i<$this->fnum; $i++){
                $this->sql .= "'".$values[$i]."'";
                if($i<$this->fnum-1){
                    $this->sql .= ",";
                }else{
                    $this->sql .= ");";
                }
            }
            // execute insert statement
            $this->result = mysqli_query($this->db->connect(),$this->sql);
            // $this->result = $this->db->connect()->query($this->sql);
            if($this->result){
                return true;
            }else{
                return false;
            }
        }
        public function login_user($tablename,$username,$password){
            $user = mysqli_real_escape_string($this->db->connect(),$username);
            $pwd = mysqli_real_escape_string($this->db->connect(),$password);
            $this->sql = "SELECT * FROM $tablename WHERE UserName = '$user' AND UserPassword='$pwd';";
            $this->result = mysqli_query($this->db->connect(),$this->sql);
            if(mysqli_num_rows($this->result)==1){
                return mysqli_fetch_array($this->result);
            }else{
                return false;
            }
        }
        public function update_data($tablename,$fields,$values,$fid,$vid){
            $this->fnum = count($fields);
            // generate update statement
            // UPDATE tablename SET col1=val1,col2=val2,...
            // WHERE condition;
            $this->sql = "UPDATE $tablename SET ";
            for($i=0; $i<$this->fnum; $i++){
                $this->sql .= $fields[$i]."='".$values[$i]."'";
                if($i<$this->fnum-1){
                    $this->sql .= ",";
                }else{
                    $this->sql .= " WHERE $fid = '$vid';";
                }
            }
            // execute update statement
            $this->result = mysqli_query($this->db->connect(),$this->sql);
            if($this->result){
                return true;
            }else{
                return false;
            }
        }
        
        public function show_data_by_id($tablename,$fid,$vid){
            $this->sql = "SELECT * FROM $tablename WHERE $fid = '$vid';";
            $this->result = mysqli_query($this->db->connect(),$this->sql);
            if($this->result){
                return mysqli_fetch_assoc($this->result);
            }else{
                return false;
            }
        }

        public function get_user_by_id($tablename, $userID) {
            // Escape user input to prevent SQL injection
            $userID = mysqli_real_escape_string($this->db->connect(), $userID);
        
            // Construct the SQL query to retrieve user data by ID
            $this->sql = "SELECT * FROM $tablename WHERE UserID = '$userID';";
        
            // Execute the SQL query
            $this->result = mysqli_query($this->db->connect(), $this->sql);
        
            // Check if the query was successful and if a user was found
            if ($this->result && mysqli_num_rows($this->result) == 1) {
                // Fetch and return the user data as an associative array
                return mysqli_fetch_assoc($this->result);
            } else {
                // User not found or query failed
                return false;
            }
        }
        
        public function update_user($tablename, $userData) {
            // Escape user input to prevent SQL injection
            $userID = mysqli_real_escape_string($this->db->connect(), $userData['UserID']);
            $userName = mysqli_real_escape_string($this->db->connect(), $userData['UserName']);
            $userType = mysqli_real_escape_string($this->db->connect(), $userData['UserType']);
            $userEmail = mysqli_real_escape_string($this->db->connect(), $userData['UserEmail']);
            // If you're storing the image as base64 encoded string, you can decode it before saving
            $userImage = base64_decode($userData['UserImage']);
        
            // Construct the SQL query to update user data
            $this->sql = "UPDATE $tablename SET 
                            UserName = '$userName',
                            UserType = '$userType',
                            UserEmail = '$userEmail',
                            UserImage = ?  -- Use prepared statement to avoid SQL injection
                            WHERE UserID = '$userID';";
        
            // Prepare the SQL statement
            $stmt = mysqli_prepare($this->db->connect(), $this->sql);
            // Bind the user image parameter
            mysqli_stmt_bind_param($stmt, "s", $userImage);
            
            // Execute the prepared statement
            $result = mysqli_stmt_execute($stmt);
        
            // Check if the query was successful
            if ($result) {
                return true;
            } else {
                return false;
            }
        }
        
        public function show_all_data($tablename,$tag){
            $data = array();
            $this->sql = "SELECT * FROM $tablename;";
            $this->result = mysqli_query($this->db->connect(),$this->sql);
            if($this->result){
                while($rows = mysqli_fetch_assoc($this->result)){
                    $data[$tag][] = $rows;
                }
                return $data;
            }else{
                return false;
            }
        }
        public function delete_data($tablename, $fid, $vid) {

            $this->sql = "DELETE FROM $tablename WHERE $fid = '$vid';";
    

            $this->result = mysqli_query($this->db->connect(), $this->sql);
    

            if ($this->result) {
                return true;
            } else {
                return false;
            }
        }
    }
?>