<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the request contains the necessary data
    if(isset($_POST['UserID']) && isset($_POST['image'])) {
        // Get the user ID from the request
        $userID = $_POST['UserID'];
        
        // Decode the base64-encoded image data
        $imageData = base64_decode($_POST['image']);

        // Set the path to save the image
        $uploadPath = "images/contacts/";

        // Generate a unique filename for the image
        $imageName = uniqid() . ".jpg";

        // Combine the upload path and image name
        $filePath = $uploadPath . $imageName;

        // Save the image to the server
        $file = fopen($filePath, "wb");
        fwrite($file, $imageData);
        fclose($file);

        // Check if the image was saved successfully
        if (file_exists($filePath)) {
            // Image upload successful
            $response = array("success" => 1, "image_path" => $filePath);
            echo json_encode($response);
        } else {
            // Image upload failed
            $response = array("success" => 0, "error" => "Failed to save image");
            echo json_encode($response);
        }
    } else {
        // Insufficient data provided
        $response = array("success" => 0, "error" => "Insufficient data provided");
        echo json_encode($response);
    }
} else {
    // Invalid request method
    $response = array("success" => 0, "error" => "Invalid request method");
    echo json_encode($response);
}
?>
