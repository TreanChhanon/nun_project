<?php
include('functions.php');

$result = array("success" => 0, "errors" => 0);

// Check if the request contains necessary data
if(isset($_POST['UserID']) && isset($_POST['UserName']) && isset($_POST['UserType']) && isset($_POST['UserEmail'])) {
    $userID = $_POST['UserID'];
    $userName = $_POST['UserName'];
    $userType = $_POST['UserType'];
    $userEmail = $_POST['UserEmail'];

    // Execute SQL query to update user data
    $func = new functions();
    $fields = array("UserName", "UserType", "UserEmail");
    $values = array($userName, $userType, $userEmail);
    $success = $func->update_data('tbluser', $fields, $values, 'UserID', $userID);

    if($success) {
        // User information updated successfully
        $result["success"] = 1;
    } else {
        // Failed to update user information
        $result["errors"] = 1;
        $result["msg_errors"] = "Failed to update user information.";
    }
} else {
    // Insufficient data provided
    $result["errors"] = 1;
    $result["msg_errors"] = "Insufficient data provided.";
}

// Output the result as JSON
echo json_encode($result);
?>
