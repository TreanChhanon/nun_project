<?php
    include('functions.php');
    $result = array("success"=>0,"errors"=>0);
    if(isset($_POST["FullNameReg"]) && isset($_POST["UserNameReg"])){
        $fullname = $_POST["FullNameReg"];
        $username = $_POST["UserNameReg"];
        $userpass = md5($_POST["PasswordReg"]);

        $fields = array("UserName","UserPassword","FullName");
        $values = array($username,$userpass,$fullname);

        // create an object of class functions
        $func = new functions();
        $insert = $func->insert_data("tbluser",$fields,$values);
        if($insert == true){
            $result["success"] = 1;
            $result["msg_success"] = "Registered user successfully!";
            print json_encode($result);
        }else{
            $result["errors"] = 2;
            $result["msg_errors"] = "Failed to register the user.";
            print json_encode($result);
        }
    }else{
        $result["errors"] = 1;
        $result["msg_errors"] = "Access denied...";
        print json_encode($result);
    }
?>