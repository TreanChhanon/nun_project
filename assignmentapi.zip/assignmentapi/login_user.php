<?php
    include('functions.php');
    $result = array("success"=>0,"errors"=>0);
    if(isset($_POST['UserNameLogin']) && isset($_POST['PasswordLogin'])){
        $user = $_POST['UserNameLogin'];
        $pwd = md5($_POST['PasswordLogin']);
        $path = "http://localhost/bbu/SRB203P19Y4S1/images/";

        $func = new functions();
        $login = $func->login_user('tbluser',$user,$pwd);
        if($login != false){
            $result["success"] = 1;
            $result["msg_success"] = "Login succeeded";
            $result["UserIDLogin"] = $login[0];
            $result["UserNameLogin"] = $login[1];
            $result["UserPassword"] = $login[2];
            $result["UserFullName"] = $login[3];
            $result["UserType"] = $login[4];
            $result["UserEmail"] = $login[5];
            $result["UserImage"] = base64_encode(file_get_contents($path.$login[6]));
            print json_encode($result);
        }else{
            $result["errors"] = 2;
            $result["msg_errors"] = "Failed to login the user.";
            print json_encode($result);
        }
    }else{
        $result["errors"] = 1;
        $result["msg_errors"] = "Access denied...";
        print json_encode($result);
    }
?>