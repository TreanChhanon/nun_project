-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 14, 2024 at 04:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategories`
--

CREATE TABLE `tblcategories` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(50) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategories`
--

INSERT INTO `tblcategories` (`CategoryID`, `CategoryName`, `Description`, `CreatedDate`, `CreatedBy`, `UpdatedDate`, `UpdatedBy`) VALUES
(2, 'kooo', 'khmer', '2024-02-09 07:53:46', NULL, '2024-02-09 15:31:48', NULL),
(5, 'dsd', 'fdf', '2024-02-09 11:37:37', NULL, NULL, NULL),
(6, 'cc', 'ss', '2024-02-09 11:41:26', NULL, NULL, NULL),
(7, 'dsd', 'ff', '2024-02-09 11:41:45', NULL, NULL, NULL),
(8, 'wew', 'rrrr', '2024-02-09 11:41:51', NULL, NULL, NULL),
(9, 'ddf', 'cd', '2024-02-09 11:42:23', NULL, NULL, NULL),
(11, 'Khmer Food', 'New Category', '2024-02-10 08:30:12', NULL, '2024-02-14 15:56:14', NULL),
(15, 'Ice', 'test', '2024-02-14 08:56:34', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `contactID` int(11) NOT NULL,
  `contactName` varchar(50) NOT NULL,
  `contactNumber` varchar(20) NOT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `contactImage` varchar(50) NOT NULL DEFAULT 'default.png',
  `favorites` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`contactID`, `contactName`, `contactNumber`, `contactEmail`, `contactImage`, `favorites`) VALUES
(4, 'Nun B', '0993434', 'chhanun@gmail.com', 'Nun B.jpg', 0),
(8, 'Nun', '0978982802', 'non@gmail.com', 'Nun.jpg', 0),
(16, 'nun', '049324', 'e', 'nun.jpg', 0),
(17, 'Test', '098773846', 'test@gmail.com', 'Test.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `CategoryID` int(11) NOT NULL,
  `Barcode` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ExpiredDate` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `Qty` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `UnitPriceIn` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `UnitPriceOut` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ProductImage` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`ProductID`, `ProductName`, `Description`, `CategoryID`, `Barcode`, `ExpiredDate`, `Qty`, `UnitPriceIn`, `UnitPriceOut`, `ProductImage`) VALUES
(2, 'Khmer Food', 'The Best Food', 2, '34334', '05/11/2024', '100', '200', '300', 'Khmer Food.jpg'),
(5, 'Yaa', 'Sweet Ice', 3, 'ssd', 'ss', 'sdsd', '3000', '5000', 'Yaa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `UserPassword` varchar(100) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `UserType` varchar(20) NOT NULL DEFAULT 'user',
  `UserEmail` varchar(100) DEFAULT NULL,
  `UserImage` varchar(100) NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`UserID`, `UserName`, `UserPassword`, `FullName`, `UserType`, `UserEmail`, `UserImage`) VALUES
(1, 'Nun', '123', 'Trean Chhanon', 'user', 'nunn@gmail.com', 'default.png'),
(2, 'Ya', '202cb962ac59075b964b07152d234b70', 'Ya', 'user', NULL, 'default.png'),
(3, 'naa', '202cb962ac59075b964b07152d234b70', 'naa', 'user', NULL, 'default.png'),
(4, 'nunn', '81dc9bdb52d04dc20036dbd8313ed055', 'nunn', 'user', NULL, 'default.png'),
(5, 'ss', '202cb962ac59075b964b07152d234b70', 'ss', 'user', NULL, 'default.png'),
(6, 'saks', '202cb962ac59075b964b07152d234b70', 'saaa', 'user', NULL, 'default.png'),
(7, 'sd', '202cb962ac59075b964b07152d234b70', 'xs', 'user', NULL, 'default.png'),
(8, 'da', '202cb962ac59075b964b07152d234b70', 'dd', 'user', NULL, 'default.png'),
(9, 'fa', '202cb962ac59075b964b07152d234b70', 'fa', 'user', NULL, 'default.png'),
(10, 'dac', '202cb962ac59075b964b07152d234b70', 'cc', 'admin', '403432', 'ca.jpg'),
(11, '', 'd41d8cd98f00b204e9800998ecf8427e', '', 'user', NULL, '.jpg'),
(13, 'VYRIYA', '202cb962ac59075b964b07152d234b70', 'Yaaa3333', 'User', 'yaa3@gmail.com', '13_image.jpg'),
(14, 'Chhanon', '202cb962ac59075b964b07152d234b70', 'Trean Chhanon', 'Administrator', 'chhanon@gmail.com', 'Chhanon.jpg'),
(15, 'Nonn', '202cb962ac59075b964b07152d234b70', 'Nun Nun', 'Admin', 'non@gmail.com', 'Non.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcategories`
--
ALTER TABLE `tblcategories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`contactID`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcategories`
--
ALTER TABLE `tblcategories`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
