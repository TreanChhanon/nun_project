<?php
include('functions.php');
$result = array("success" => 0, "errors" => 0);
if (isset($_POST['ProductName']) && isset($_POST['Description'])) {
    $name = $_POST['ProductName'];
    $description = $_POST['Description'];
    $categoryID = $_POST['CategoryID'];
    $barcode = $_POST['Barcode'];
    $expiredDate = $_POST['ExpiredDate'];
    $qty = $_POST['Qty'];
    $unitPriceIn = $_POST['UnitPriceIn'];
    $unitPriceOut = $_POST['UnitPriceOut'];
    $image = $_POST['ProductImage'];
    $image_name = $name . ".jpg"; 
    $path = "images/contacts/" . $image_name;

    if ($image == "NoImage") {
        $fields = array(
            "ProductName", "Description", "CategoryID", 
            "Barcode", "ExpiredDate", "Qty", 
            "UnitPriceIn", "UnitPriceOut"
        );
        $values = array(
            $name, $description, $categoryID, 
            $barcode, $expiredDate, $qty, 
            $unitPriceIn, $unitPriceOut
        );
    } else {
        $fields = array(
            "ProductName", "Description", "CategoryID", 
            "Barcode", "ExpiredDate", "Qty", 
            "UnitPriceIn", "UnitPriceOut", "ProductImage"
        );
        $values = array(
            $name, $description, $categoryID, 
            $barcode, $expiredDate, $qty, 
            $unitPriceIn, $unitPriceOut, $image_name
        );
    }
    // Create an object of class functions
    $func = new functions();
    $insert = $func->insert_data('tblproducts', $fields, $values);
    if ($insert == true) {
        if ($image != "NoImage") {
            file_put_contents($path, base64_decode($image));
        }
        $result["success"] = 1;
        $result["msg_success"] = "Product is created";
        print json_encode($result);
    } else {
        $result["errors"] = 2;
        $result["msg_errors"] = "Failed to create the product.";
        print json_encode($result);
    }
} else {
    $result["errors"] = 1;
    $result["msg_errors"] = "Access denied...";
    print json_encode($result);
}
?>
